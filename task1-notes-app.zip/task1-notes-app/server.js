
const express = require("express");
const path = require("path");
const Database = require("better-sqlite3");

const app = express();
const db = new Database(path.join(__dirname, "notes.db"));

// Create the database table automatically
db.exec(`
  CREATE TABLE IF NOT EXISTS notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    content TEXT NOT NULL DEFAULT '',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  )
`);

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// GET: View and search notes
app.get("/api/notes", (req, res) => {
  const search = String(req.query.search || "").trim();

  const notes = search
    ? db.prepare(`
        SELECT * FROM notes
        WHERE title LIKE ? OR content LIKE ?
        ORDER BY id DESC
      `).all(`%${search}%`, `%${search}%`)
    : db.prepare("SELECT * FROM notes ORDER BY id DESC").all();

  res.json(notes);
});

// POST: Create a note
app.post("/api/notes", (req, res) => {
  const title = typeof req.body.title === "string"
    ? req.body.title.trim() : "";
  const content = typeof req.body.content === "string"
    ? req.body.content.trim() : "";

  if (!title) {
    return res.status(400).json({
      error: "Title is required"
    });
  }

  if (title.length > 120 || content.length > 10000) {
    return res.status(400).json({
      error: "Text is too long"
    });
  }

  const result = db.prepare(
    "INSERT INTO notes (title, content) VALUES (?, ?)"
  ).run(title, content);

  res.status(201).json(
    db.prepare("SELECT * FROM notes WHERE id = ?")
      .get(result.lastInsertRowid)
  );
});

// PUT: Update a note
app.put("/api/notes/:id", (req, res) => {
  const id = Number(req.params.id);
  const title = typeof req.body.title === "string"
    ? req.body.title.trim() : "";
  const content = typeof req.body.content === "string"
    ? req.body.content.trim() : "";

  if (!Number.isInteger(id) || id < 1) {
    return res.status(400).json({ error: "Invalid note ID" });
  }

  if (!title || title.length > 120 || content.length > 10000) {
    return res.status(400).json({
      error: "Invalid note details"
    });
  }

  const result = db.prepare(
    "UPDATE notes SET title = ?, content = ? WHERE id = ?"
  ).run(title, content, id);

  if (!result.changes) {
    return res.status(404).json({ error: "Note not found" });
  }

  res.json({ message: "Note updated successfully" });
});

// DELETE: Delete a note
app.delete("/api/notes/:id", (req, res) => {
  const id = Number(req.params.id);

  if (!Number.isInteger(id) || id < 1) {
    return res.status(400).json({ error: "Invalid note ID" });
  }

  const result = db.prepare(
    "DELETE FROM notes WHERE id = ?"
  ).run(id);

  if (!result.changes) {
    return res.status(404).json({ error: "Note not found" });
  }

  res.json({ message: "Note deleted successfully" });
});

app.listen(3000, () => {
  console.log("Notes App running at http://localhost:3000");
});
