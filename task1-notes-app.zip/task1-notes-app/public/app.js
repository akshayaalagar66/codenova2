
const form = document.getElementById("noteForm");
const titleInput = document.getElementById("title");
const contentInput = document.getElementById("content");
const noteId = document.getElementById("noteId");
const notesBox = document.getElementById("notes");
const empty = document.getElementById("empty");
const search = document.getElementById("search");
const cancelBtn = document.getElementById("cancelBtn");

let toastTimer;

function toast(message) {
  const el = document.getElementById("toast");
  el.textContent = message;
  el.style.display = "block";

  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    el.style.display = "none";
  }, 2500);
}

async function api(url, options = {}) {
  let response;

  try {
    response = await fetch(url, {
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...(options.headers || {})
      }
    });
  } catch {
    throw new Error("Server connection failed. Check npm start.");
  }

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error || "Something went wrong");
  }

  return data;
}

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[char]);
}

async function loadNotes() {
  try {
    const notes = await api(
      "/api/notes?search=" + encodeURIComponent(search.value)
    );

    notesBox.innerHTML = notes.map(note => `
      <article class="note">
        <h3>${escapeHTML(note.title)}</h3>
        <p>${escapeHTML(note.content || "No content")}</p>
        <button data-edit="${note.id}">Edit</button>
        <button class="delete" data-delete="${note.id}">Delete</button>
      </article>
    `).join("");

    empty.hidden = notes.length > 0;

    if (!notes.length) {
      empty.textContent = search.value.trim()
        ? "No matching notes found."
        : "No notes yet. Create your first note!";
    }
  } catch (error) {
    toast(error.message);
  }
}

function resetForm() {
  form.reset();
  noteId.value = "";

  document.getElementById("formHeading").textContent =
    "Create a Note";

  document.getElementById("saveBtn").textContent =
    "+ Save Note";

  cancelBtn.hidden = true;
}

form.addEventListener("submit", async event => {
  event.preventDefault();

  const payload = {
    title: titleInput.value.trim(),
    content: contentInput.value.trim()
  };

  if (!payload.title) {
    toast("Please enter a title.");
    return;
  }

  try {
    const editing = Boolean(noteId.value);

    await api(
      editing ? `/api/notes/${noteId.value}` : "/api/notes",
      {
        method: editing ? "PUT" : "POST",
        body: JSON.stringify(payload)
      }
    );

    toast(editing ? "Note updated!" : "Note created!");
    resetForm();
    await loadNotes();
  } catch (error) {
    toast(error.message);
  }
});

cancelBtn.addEventListener("click", resetForm);
search.addEventListener("input", loadNotes);

notesBox.addEventListener("click", async event => {
  const editId = event.target.dataset.edit;
  const deleteId = event.target.dataset.delete;

  if (editId) {
    try {
      const notes = await api("/api/notes");
      const note = notes.find(n => n.id === Number(editId));

      if (!note) return toast("Note not found.");

      noteId.value = note.id;
      titleInput.value = note.title;
      contentInput.value = note.content;

      document.getElementById("formHeading").textContent =
        "Edit Note";

      document.getElementById("saveBtn").textContent =
        "Save Changes";

      cancelBtn.hidden = false;
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (error) {
      toast(error.message);
    }
  }

  if (deleteId && confirm("Delete this note?")) {
    try {
      await api(`/api/notes/${deleteId}`, {
        method: "DELETE"
      });

      toast("Note deleted!");
      await loadNotes();
    } catch (error) {
      toast(error.message);
    }
  }
});

loadNotes();
