# 🎓 Student Project Showcase — Community Portal & Moderation

A full-stack portal where students submit projects, admins moderate them, and the public gallery shows **approved projects only**.

**Stack:** React 18 + Vite · Node.js + Express · SQLite (relational, via `better-sqlite3`) · JWT admin auth

## Features
- Public submission form: title, student name, description, tags, GitHub link, live preview URL
- Gallery grid of approved projects with debounced search and clickable tag filters
- Admin portal (JWT login): review pending, approve or reject (with optional reason)
- Submissions stay `pending` and hidden until approved

## Setup
Requires **Node.js 18+** (uses built-in `fetch`).

```bash
npm run install:all        # installs root, server and client deps
cp server/.env.example server/.env    # (already created) edit the admin password!
npm run seed               # optional: sample projects (3 approved, 1 pending)
npm run dev                # API → :5000, web → http://localhost:5173
```

| Page | URL |
|------|-----|
| Gallery | http://localhost:5173/ |
| Submit | http://localhost:5173/submit |
| Admin | http://localhost:5173/admin (default `admin` / `admin123` — change in `.env`) |

### Production
```bash
npm run build && npm start   # Express serves client/dist and the API on :5000
```
Deploy to Render / Railway (single web service). Set `JWT_SECRET`, `ADMIN_USERNAME`, `ADMIN_PASSWORD`, `CLIENT_ORIGIN`.

## API routes
| Method | Route | Auth | Description |
|--------|-------|------|-------------|
| GET | `/api/projects?search=&tag=` | public | Approved projects only, filtered |
| GET | `/api/projects/tags` | public | Tags (with counts) on approved projects |
| POST | `/api/projects` | public (rate-limited) | Validate and create a **pending** project |
| POST | `/api/admin/login` | public (rate-limited) | Returns JWT |
| GET | `/api/admin/stats` | admin | Counts by status |
| GET | `/api/admin/projects?status=pending\|approved\|rejected\|all` | admin | Moderation queue |
| PATCH | `/api/admin/projects/:id/status` | admin | Body `{status, note}` |

## Architecture
```
Browser (React) ──/api──▶ Express ──▶ SQLite
   pages/Gallery, Submit, Admin     routes → middleware(validate, auth) → db
```
- **Moderation gate:** the public query is hard-coded to `status = 'approved'`; new rows are always inserted as `pending`.
- **URL validation (before saving):** `validate.js` checks format (GitHub must be `github.com/<user>/<repo>`, demo must be a public http(s) site) and then pings both URLs; 404/410/5xx/unreachable are rejected with field-level errors (HTTP 422).
- **Reactive filtering:** `Gallery.jsx` re-fetches on `[debouncedSearch, tag]` changes and ignores stale responses.
- **Auth:** admin credentials from env, constant-time compare, 8h JWT, `requireAdmin` guards all `/api/admin/*` (except login).
- Tags are stored as `,react,node,` so `LIKE '%,react,%'` matches whole tags only.

## Acceptance checklist
- [x] Hidden until admin approves
- [x] GitHub and demo URLs validated before recording
- [x] Search and tag filters update the grid reactively
