import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar.jsx';
import Gallery from './pages/Gallery.jsx';
import Submit from './pages/Submit.jsx';
import Admin from './pages/Admin.jsx';

export default function App() {
  return (
    <>
      <div className="bg-glow" aria-hidden="true" />
      <Navbar />
      <main className="container">
        <Routes>
          <Route path="/" element={<Gallery />} />
          <Route path="/submit" element={<Submit />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="*" element={<p className="empty">Page not found.</p>} />
        </Routes>
      </main>
      <footer className="footer">Built with React + Express + SQLite · Student Project Showcase</footer>
    </>
  );
}
