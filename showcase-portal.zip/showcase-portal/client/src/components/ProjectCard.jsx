const GRADIENTS = [
  'linear-gradient(135deg,#6366f1,#8b5cf6)',
  'linear-gradient(135deg,#06b6d4,#3b82f6)',
  'linear-gradient(135deg,#ec4899,#f97316)',
  'linear-gradient(135deg,#10b981,#06b6d4)',
  'linear-gradient(135deg,#f59e0b,#ef4444)',
];

const initials = (name) =>
  name.split(' ').filter(Boolean).slice(0, 2).map((w) => w[0].toUpperCase()).join('');

export default function ProjectCard({ project, onTagClick, children }) {
  const { title, studentName, description, tags, githubUrl, demoUrl } = project;
  return (
    <article className="card">
      <div className="card-banner" style={{ background: GRADIENTS[project.id % GRADIENTS.length] }}>
        <span className="card-title-ghost">{title.slice(0, 2)}</span>
      </div>
      <div className="card-body">
        <h3>{title}</h3>
        <div className="author">
          <span className="avatar">{initials(studentName)}</span>
          <span>{studentName}</span>
        </div>
        <p className="desc">{description}</p>
        <div className="tags">
          {tags.map((t) => (
            <button key={t} className="tag" onClick={() => onTagClick?.(t)} type="button">#{t}</button>
          ))}
        </div>
        <div className="card-actions">
          <a className="btn btn-ghost" href={githubUrl} target="_blank" rel="noreferrer">GitHub ↗</a>
          <a className="btn btn-primary" href={demoUrl} target="_blank" rel="noreferrer">Live demo ↗</a>
        </div>
        {children}
      </div>
    </article>
  );
}
