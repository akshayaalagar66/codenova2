import { NavLink, Link } from 'react-router-dom';

export default function Navbar() {
  return (
    <header className="nav">
      <div className="nav-inner">
        <Link to="/" className="brand">
          <span className="brand-dot">◆</span> Showcase<span className="brand-light">Hub</span>
        </Link>
        <nav className="nav-links">
          <NavLink to="/" end>Gallery</NavLink>
          <NavLink to="/submit">Submit</NavLink>
          <NavLink to="/admin">Admin</NavLink>
        </nav>
      </div>
    </header>
  );
}
