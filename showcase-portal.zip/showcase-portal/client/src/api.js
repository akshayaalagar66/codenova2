const BASE = '/api';

export const getToken = () => localStorage.getItem('adminToken');
export const setToken = (t) => (t ? localStorage.setItem('adminToken', t) : localStorage.removeItem('adminToken'));

async function request(path, { method = 'GET', body, auth = false } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (auth && getToken()) headers.Authorization = `Bearer ${getToken()}`;

  const res = await fetch(BASE + path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.error || 'Request failed');
    err.status = res.status;
    err.fields = data.errors || {};
    throw err;
  }
  return data;
}

export const api = {
  listProjects: (search, tag) => {
    const p = new URLSearchParams();
    if (search) p.set('search', search);
    if (tag) p.set('tag', tag);
    return request(`/projects?${p}`);
  },
  listTags: () => request('/projects/tags'),
  submitProject: (body) => request('/projects', { method: 'POST', body }),
  login: (body) => request('/admin/login', { method: 'POST', body }),
  adminStats: () => request('/admin/stats', { auth: true }),
  adminProjects: (status) => request(`/admin/projects?status=${status}`, { auth: true }),
  moderate: (id, status, note) =>
    request(`/admin/projects/${id}/status`, { method: 'PATCH', body: { status, note }, auth: true }),
};
