import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';
import useDebounce from '../hooks/useDebounce.js';
import ProjectCard from '../components/ProjectCard.jsx';

export default function Gallery() {
  const [search, setSearch] = useState('');
  const [tag, setTag] = useState('');
  const [tags, setTags] = useState([]);
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const debouncedSearch = useDebounce(search, 300);

  useEffect(() => { api.listTags().then(setTags).catch(() => {}); }, []);

  // Re-fetch whenever the search text or tag changes → grid updates reactively
  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    api.listProjects(debouncedSearch, tag)
      .then((data) => { if (!cancelled) { setProjects(data); setError(''); } })
      .catch((e) => !cancelled && setError(e.message))
      .finally(() => !cancelled && setLoading(false));
    return () => { cancelled = true; };
  }, [debouncedSearch, tag]);

  const clear = () => { setSearch(''); setTag(''); };

  return (
    <>
      <section className="hero">
        <span className="pill">🎓 Community Portal</span>
        <h1>Discover what students are <span className="gradient-text">building</span></h1>
        <p>Browse admin-approved projects, filter by tech, and share your own work with the community.</p>
        <Link to="/submit" className="btn btn-primary btn-lg">Submit your project →</Link>
      </section>

      <section className="toolbar">
        <div className="search">
          <span>🔍</span>
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by title, student, tech…"
            aria-label="Search projects"
          />
          {search && <button className="clear" onClick={() => setSearch('')} aria-label="Clear search">✕</button>}
        </div>
        <div className="chips">
          <button className={`chip ${tag === '' ? 'active' : ''}`} onClick={() => setTag('')}>All</button>
          {tags.map((t) => (
            <button key={t.name} className={`chip ${tag === t.name ? 'active' : ''}`}
              onClick={() => setTag(tag === t.name ? '' : t.name)}>
              #{t.name} <small>{t.count}</small>
            </button>
          ))}
        </div>
      </section>

      <p className="result-count">
        {loading ? 'Loading…' : `${projects.length} project${projects.length === 1 ? '' : 's'}`}
        {(search || tag) && <button className="link" onClick={clear}> · Reset filters</button>}
      </p>

      {error && <p className="alert alert-error">{error}</p>}

      {!loading && !error && projects.length === 0 ? (
        <div className="empty">
          <div className="empty-emoji">🛰️</div>
          <h3>No approved projects found</h3>
          <p>Try a different search or tag — or be the first to submit one.</p>
        </div>
      ) : (
        <section className="grid">
          {projects.map((p) => <ProjectCard key={p.id} project={p} onTagClick={setTag} />)}
        </section>
      )}
    </>
  );
}
