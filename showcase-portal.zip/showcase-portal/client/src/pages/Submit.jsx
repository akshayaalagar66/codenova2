import { useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';

const EMPTY = { title: '', studentName: '', description: '', tags: '', githubUrl: '', demoUrl: '' };

function Field({ label, error, hint, children }) {
  return (
    <label className={`field ${error ? 'has-error' : ''}`}>
      <span className="field-label">{label}</span>
      {children}
      {error ? <span className="field-error">{error}</span> : hint && <span className="field-hint">{hint}</span>}
    </label>
  );
}

export default function Submit() {
  const [form, setForm] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const [formError, setFormError] = useState('');

  const set = (k) => (e) => {
    setForm({ ...form, [k]: e.target.value });
    if (errors[k]) setErrors({ ...errors, [k]: undefined });
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setFormError('');
    try {
      await api.submitProject(form);
      setDone(true);
      setForm(EMPTY);
      setErrors({});
    } catch (err) {
      setErrors(err.fields || {});
      setFormError(err.message);
    } finally {
      setBusy(false);
    }
  };

  if (done)
    return (
      <div className="panel success">
        <div className="empty-emoji">✅</div>
        <h2>Submitted for review!</h2>
        <p>Your project is <b>pending</b>. It will appear in the gallery once an admin approves it.</p>
        <div className="row">
          <button className="btn btn-primary" onClick={() => setDone(false)}>Submit another</button>
          <Link className="btn btn-ghost" to="/">Back to gallery</Link>
        </div>
      </div>
    );

  return (
    <form className="panel form" onSubmit={onSubmit} noValidate>
      <h2>Submit your project</h2>
      <p className="muted">We check your links before saving. Projects go live after admin approval.</p>
      {formError && <p className="alert alert-error">{formError}</p>}

      <div className="two-col">
        <Field label="Project title" error={errors.title}>
          <input value={form.title} onChange={set('title')} placeholder="e.g. CampusConnect" />
        </Field>
        <Field label="Student name" error={errors.studentName}>
          <input value={form.studentName} onChange={set('studentName')} placeholder="Your full name" />
        </Field>
      </div>

      <Field label="Description" error={errors.description} hint={`${form.description.length}/1000 · min 20 characters`}>
        <textarea rows="4" value={form.description} onChange={set('description')} placeholder="What does it do? What did you use?" />
      </Field>

      <Field label="Tags" error={errors.tags} hint="Comma separated, up to 6 — e.g. react, node, ml">
        <input value={form.tags} onChange={set('tags')} placeholder="react, node, mongodb" />
      </Field>

      <div className="two-col">
        <Field label="GitHub repository" error={errors.githubUrl}>
          <input value={form.githubUrl} onChange={set('githubUrl')} placeholder="https://github.com/you/repo" />
        </Field>
        <Field label="Live preview URL" error={errors.demoUrl}>
          <input value={form.demoUrl} onChange={set('demoUrl')} placeholder="https://your-demo.vercel.app" />
        </Field>
      </div>

      <button className="btn btn-primary btn-lg" disabled={busy}>
        {busy ? 'Validating links…' : 'Submit for review'}
      </button>
    </form>
  );
}
