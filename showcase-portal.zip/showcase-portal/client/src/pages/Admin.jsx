import { useCallback, useEffect, useState } from 'react';
import { api, getToken, setToken } from '../api.js';
import ProjectCard from '../components/ProjectCard.jsx';

function Login({ onLogin }) {
  const [form, setForm] = useState({ username: '', password: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      const { token } = await api.login(form);
      setToken(token);
      onLogin();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <form className="panel form narrow" onSubmit={submit}>
      <h2>Admin sign in 🔐</h2>
      <p className="muted">Only designated moderators can review submissions.</p>
      {error && <p className="alert alert-error">{error}</p>}
      <label className="field"><span className="field-label">Username</span>
        <input value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} autoFocus />
      </label>
      <label className="field"><span className="field-label">Password</span>
        <input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
      </label>
      <button className="btn btn-primary btn-lg" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'}</button>
    </form>
  );
}

function Dashboard({ onLogout }) {
  const [tab, setTab] = useState('pending');
  const [stats, setStats] = useState({ pending: 0, approved: 0, rejected: 0 });
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const handleError = useCallback((e) => {
    if (e.status === 401) { setToken(null); onLogout(); } else setError(e.message);
  }, [onLogout]);

  const load = useCallback(() => {
    setLoading(true);
    Promise.all([api.adminStats(), api.adminProjects(tab)])
      .then(([s, list]) => { setStats(s); setItems(list); setError(''); })
      .catch(handleError)
      .finally(() => setLoading(false));
  }, [tab, handleError]);

  useEffect(load, [load]);

  const moderate = async (id, status) => {
    let note = '';
    if (status === 'rejected') {
      note = window.prompt('Reason for rejection (optional):') ?? null;
      if (note === null) return;
    }
    try { await api.moderate(id, status, note); load(); } catch (e) { handleError(e); }
  };

  return (
    <>
      <div className="admin-head">
        <div>
          <h2>Moderation dashboard</h2>
          <p className="muted">Review submissions before they appear in the public gallery.</p>
        </div>
        <button className="btn btn-ghost" onClick={() => { setToken(null); onLogout(); }}>Log out</button>
      </div>

      <div className="stats">
        {['pending', 'approved', 'rejected'].map((s) => (
          <button key={s} className={`stat stat-${s} ${tab === s ? 'active' : ''}`} onClick={() => setTab(s)}>
            <b>{stats[s]}</b><span>{s}</span>
          </button>
        ))}
      </div>

      {error && <p className="alert alert-error">{error}</p>}
      {loading ? <p className="muted">Loading…</p> : items.length === 0 ? (
        <div className="empty"><div className="empty-emoji">🎉</div><h3>Nothing {tab} right now</h3></div>
      ) : (
        <section className="grid">
          {items.map((p) => (
            <ProjectCard key={p.id} project={p}>
              {p.moderationNote && <p className="note">Note: {p.moderationNote}</p>}
              <div className="mod-actions">
                {p.status !== 'approved' && <button className="btn btn-approve" onClick={() => moderate(p.id, 'approved')}>✓ Approve</button>}
                {p.status !== 'rejected' && <button className="btn btn-reject" onClick={() => moderate(p.id, 'rejected')}>✕ Reject</button>}
              </div>
            </ProjectCard>
          ))}
        </section>
      )}
    </>
  );
}

export default function Admin() {
  const [authed, setAuthed] = useState(!!getToken());
  return authed ? <Dashboard onLogout={() => setAuthed(false)} /> : <Login onLogin={() => setAuthed(true)} />;
}
