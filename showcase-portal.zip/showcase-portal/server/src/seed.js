import db from './db.js';

const samples = [
  ['CampusConnect', 'Priya S', 'A campus social app with event feeds, club pages and real-time chat for students.', ',react,node,socket.io,', 'https://github.com/example/campusconnect', 'https://example.com', 'approved'],
  ['CropDoctor AI', 'Arjun R', 'Detects plant leaf diseases from a phone photo using a CNN and suggests treatments.', ',python,tensorflow,ml,', 'https://github.com/example/cropdoctor', 'https://example.com', 'approved'],
  ['BudgetBuddy', 'Meena K', 'Personal finance tracker with monthly charts, category budgets and CSV export.', ',react,charts,express,', 'https://github.com/example/budgetbuddy', 'https://example.com', 'approved'],
  ['SmartAttendance', 'Karthik V', 'Face-recognition attendance system for classrooms with a faculty dashboard.', ',opencv,python,flask,', 'https://github.com/example/smartattendance', 'https://example.com', 'pending'],
];

db.exec('DELETE FROM projects');
const ins = db.prepare(
  'INSERT INTO projects (title, student_name, description, tags, github_url, demo_url, status) VALUES (?,?,?,?,?,?,?)'
);
samples.forEach((s) => ins.run(...s));
console.log(`Seeded ${samples.length} projects (3 approved, 1 pending).`);
