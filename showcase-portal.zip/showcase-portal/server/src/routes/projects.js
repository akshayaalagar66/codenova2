import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import db from '../db.js';
import { toDto } from '../utils/dto.js';
import { validateSubmission } from '../middleware/validate.js';

const router = Router();

const submitLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  limit: 15,
  message: { error: 'Too many submissions, please try again later' },
});

// PUBLIC FEED — approved only (search + tag filter)
router.get('/', (req, res) => {
  const search = String(req.query.search || '').trim();
  const tag = String(req.query.tag || '').trim().toLowerCase();
  const params = [];
  let sql = "SELECT * FROM projects WHERE status = 'approved'";

  if (search) {
    sql += ' AND (title LIKE ? OR student_name LIKE ? OR description LIKE ? OR tags LIKE ?)';
    const q = `%${search}%`;
    params.push(q, q, q, q);
  }
  if (tag) {
    sql += ' AND tags LIKE ?';
    params.push(`%,${tag},%`);
  }
  sql += ' ORDER BY created_at DESC, id DESC';

  res.json(db.prepare(sql).all(...params).map(toDto));
});

// Tags that exist on approved projects (with counts)
router.get('/tags', (_req, res) => {
  const counts = {};
  db.prepare("SELECT tags FROM projects WHERE status = 'approved'")
    .all()
    .forEach((r) => r.tags.split(',').filter(Boolean).forEach((t) => (counts[t] = (counts[t] || 0) + 1)));
  const tags = Object.entries(counts)
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
  res.json(tags);
});

// PUBLIC SUBMISSION — always lands as "pending"
router.post('/', submitLimiter, validateSubmission, (req, res) => {
  const c = req.clean;
  const info = db
    .prepare(
      `INSERT INTO projects (title, student_name, description, tags, github_url, demo_url, status)
       VALUES (?, ?, ?, ?, ?, ?, 'pending')`
    )
    .run(c.title, c.studentName, c.description, c.tags, c.githubUrl, c.demoUrl);

  res.status(201).json({
    id: info.lastInsertRowid,
    status: 'pending',
    message: 'Thanks! Your project is awaiting admin review.',
  });
});

export default router;
