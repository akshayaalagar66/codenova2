import { Router } from 'express';
import crypto from 'crypto';
import rateLimit from 'express-rate-limit';
import db from '../db.js';
import { toDto } from '../utils/dto.js';
import { requireAdmin, signToken } from '../middleware/auth.js';

const router = Router();
const sha = (s) => crypto.createHash('sha256').update(String(s)).digest();
const safeEqual = (a, b) => crypto.timingSafeEqual(sha(a), sha(b));

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  message: { error: 'Too many login attempts, try again in 15 minutes' },
});

router.post('/login', loginLimiter, (req, res) => {
  const { username = '', password = '' } = req.body || {};
  const okUser = safeEqual(username, process.env.ADMIN_USERNAME || 'admin');
  const okPass = safeEqual(password, process.env.ADMIN_PASSWORD || 'admin123');
  if (!okUser || !okPass) return res.status(401).json({ error: 'Invalid username or password' });
  res.json({ token: signToken(username), username });
});

// Everything below needs a valid admin token
router.use(requireAdmin);

router.get('/stats', (_req, res) => {
  const rows = db.prepare('SELECT status, COUNT(*) AS n FROM projects GROUP BY status').all();
  const stats = { pending: 0, approved: 0, rejected: 0 };
  rows.forEach((r) => (stats[r.status] = r.n));
  res.json(stats);
});

router.get('/projects', (req, res) => {
  const status = String(req.query.status || 'pending');
  const rows =
    status === 'all'
      ? db.prepare('SELECT * FROM projects ORDER BY created_at DESC, id DESC').all()
      : db.prepare('SELECT * FROM projects WHERE status = ? ORDER BY created_at DESC, id DESC').all(status);
  res.json(rows.map(toDto));
});

router.patch('/projects/:id/status', (req, res) => {
  const { status, note = '' } = req.body || {};
  if (!['approved', 'rejected', 'pending'].includes(status))
    return res.status(400).json({ error: 'Status must be approved, rejected or pending' });

  const info = db
    .prepare("UPDATE projects SET status = ?, moderation_note = ?, reviewed_at = datetime('now') WHERE id = ?")
    .run(status, String(note).slice(0, 300) || null, req.params.id);
  if (!info.changes) return res.status(404).json({ error: 'Project not found' });

  res.json(toDto(db.prepare('SELECT * FROM projects WHERE id = ?').get(req.params.id)));
});

export default router;
