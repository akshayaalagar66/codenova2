import {
  githubFormatError, demoFormatError, isReachable, parseHttpUrl,
} from '../utils/urlCheck.js';

const TAG_RE = /^[a-z0-9+#.\- ]{1,20}$/;

export function normalizeTags(input) {
  const list = Array.isArray(input) ? input : String(input || '').split(',');
  return [...new Set(list.map((t) => String(t).trim().toLowerCase()).filter(Boolean))];
}

/** Validates a submission BEFORE it is recorded. Puts clean data on req.clean. */
export async function validateSubmission(req, res, next) {
  try {
    const b = req.body || {};
    const errors = {};

    const title = String(b.title || '').trim();
    const studentName = String(b.studentName || '').trim();
    const description = String(b.description || '').trim();
    const tags = normalizeTags(b.tags);
    const githubUrl = String(b.githubUrl || '').trim();
    const demoUrl = String(b.demoUrl || '').trim();

    if (title.length < 3 || title.length > 100) errors.title = 'Title must be 3–100 characters';
    if (studentName.length < 2 || studentName.length > 80) errors.studentName = 'Name must be 2–80 characters';
    if (description.length < 20 || description.length > 1000) errors.description = 'Description must be 20–1000 characters';
    if (tags.length < 1 || tags.length > 6) errors.tags = 'Add 1–6 tags';
    else if (tags.some((t) => !TAG_RE.test(t))) errors.tags = 'Tags: max 20 chars, letters/numbers only';

    errors.githubUrl = githubFormatError(githubUrl) || undefined;
    errors.demoUrl = demoFormatError(demoUrl) || undefined;

    // Only hit the network once the formats are fine
    const [ghOk, demoOk] = await Promise.all([
      errors.githubUrl ? true : isReachable(githubUrl),
      errors.demoUrl ? true : isReachable(demoUrl),
    ]);
    if (!ghOk) errors.githubUrl = 'We could not reach this GitHub repository (is it public?)';
    if (!demoOk) errors.demoUrl = 'We could not reach this live demo link';

    Object.keys(errors).forEach((k) => errors[k] === undefined && delete errors[k]);
    if (Object.keys(errors).length)
      return res.status(422).json({ error: 'Please fix the highlighted fields', errors });

    req.clean = {
      title, studentName, description,
      tags: `,${tags.join(',')},`,
      githubUrl: parseHttpUrl(githubUrl).href,
      demoUrl: parseHttpUrl(demoUrl).href,
    };
    next();
  } catch (err) {
    next(err);
  }
}
