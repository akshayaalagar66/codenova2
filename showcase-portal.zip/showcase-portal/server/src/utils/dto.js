// Convert a DB row into the JSON shape the frontend consumes.
export const toDto = (r) => ({
  id: r.id,
  title: r.title,
  studentName: r.student_name,
  description: r.description,
  tags: r.tags.split(',').filter(Boolean),
  githubUrl: r.github_url,
  demoUrl: r.demo_url,
  status: r.status,
  moderationNote: r.moderation_note,
  createdAt: r.created_at,
  reviewedAt: r.reviewed_at,
});
