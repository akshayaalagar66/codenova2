export function parseHttpUrl(value) {
  try {
    const u = new URL(String(value).trim());
    return ['http:', 'https:'].includes(u.protocol) ? u : null;
  } catch {
    return null;
  }
}

/** Returns an error string, or null when the GitHub URL looks right. */
export function githubFormatError(value) {
  const u = parseHttpUrl(value);
  if (!u) return 'Enter a valid link starting with http:// or https://';
  if (!['github.com', 'www.github.com'].includes(u.hostname))
    return 'Link must point to github.com';
  if (u.pathname.split('/').filter(Boolean).length < 2)
    return 'Use a repository link, e.g. https://github.com/username/repo';
  return null;
}

export function demoFormatError(value) {
  const u = parseHttpUrl(value);
  if (!u) return 'Enter a valid link starting with http:// or https://';
  const h = u.hostname;
  if (h === 'localhost' || h.startsWith('127.') || !h.includes('.'))
    return 'Demo link must be a public website, not localhost';
  return null;
}

/** Live check — does the page actually exist? (404/410/5xx/network error => no) */
export async function isReachable(url) {
  if (process.env.SKIP_URL_REACHABILITY === 'true') return true;
  const attempt = async (method) => {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 6000);
    try {
      return await fetch(url, { method, redirect: 'follow', signal: ctrl.signal });
    } finally {
      clearTimeout(timer);
    }
  };
  try {
    let res = await attempt('HEAD');
    if (res.status === 405 || res.status === 501) res = await attempt('GET');
    return ![404, 410].includes(res.status) && res.status < 500;
  } catch {
    return false;
  }
}
