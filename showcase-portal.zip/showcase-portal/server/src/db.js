import Database from 'better-sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const db = new Database(path.join(__dirname, '..', 'showcase.db'));

db.pragma('journal_mode = WAL');
db.exec(`
  CREATE TABLE IF NOT EXISTS projects (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    title           TEXT NOT NULL,
    student_name    TEXT NOT NULL,
    description     TEXT NOT NULL,
    tags            TEXT NOT NULL DEFAULT '',          -- stored as ",react,node,"
    github_url      TEXT NOT NULL,
    demo_url        TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending','approved','rejected')),
    moderation_note TEXT,
    created_at      TEXT DEFAULT CURRENT_TIMESTAMP,
    reviewed_at     TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status);
`);

export default db;
