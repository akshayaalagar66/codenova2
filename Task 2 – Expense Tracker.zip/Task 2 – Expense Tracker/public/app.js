
const form = document.getElementById("transactionForm");
const transactionList = document.getElementById("transactionList");
const message = document.getElementById("message");

const totalIncome = document.getElementById("totalIncome");
const totalExpenses = document.getElementById("totalExpenses");
const savings = document.getElementById("savings");

const submitButton = document.getElementById("submitButton");

// Set today's date
document.getElementById("date").value =
    new Date().toLocaleDateString("en-CA");

// Currency format
function formatCurrency(amount) {
    return new Intl.NumberFormat("en-IN", {
        style: "currency",
        currency: "INR",
        maximumFractionDigits: 2
    }).format(amount);
}

// Show message
function showMessage(text, error = false) {
    message.textContent = text;
    message.style.color = error ? "#e64c62" : "#16a36a";
}

// Load financial summary
async function loadSummary() {
    const response = await fetch("/api/summary");

    if (!response.ok) {
        throw new Error("Unable to load summary");
    }

    const data = await response.json();

    totalIncome.textContent =
        formatCurrency(Number(data.totalIncome) || 0);

    totalExpenses.textContent =
        formatCurrency(Number(data.totalExpenses) || 0);

    savings.textContent =
        formatCurrency(Number(data.savings) || 0);
}

// Load transaction history
async function loadTransactions() {
    const response = await fetch("/api/transactions");

    if (!response.ok) {
        throw new Error("Unable to load transactions");
    }

    const transactions = await response.json();

    transactionList.innerHTML = "";

    if (transactions.length === 0) {
        transactionList.innerHTML = `
            <tr>
                <td colspan="5" class="empty">
                    No transactions found. Add your first transaction!
                </td>
            </tr>
        `;
        return;
    }

    transactions.forEach(transaction => {
        const isIncome = transaction.type === "income";

        const row = document.createElement("tr");

        const date = document.createElement("td");
        date.textContent = transaction.date;

        const description = document.createElement("td");
        description.textContent =
            transaction.description || "No description";

        const category = document.createElement("td");
        category.textContent = transaction.category;

        const amount = document.createElement("td");
        amount.className = isIncome
            ? "income-amount"
            : "expense-amount";

        amount.textContent =
            (isIncome ? "+" : "-") +
            formatCurrency(Number(transaction.amount));

        const action = document.createElement("td");

        const badge = document.createElement("span");
        badge.className = isIncome
            ? "badge income-badge"
            : "badge expense-badge";

        badge.textContent = isIncome ? "Income" : "Expense";

        const deleteButton = document.createElement("button");
        deleteButton.className = "delete-btn";
        deleteButton.textContent = "Delete";

        deleteButton.addEventListener("click", () => {
            deleteTransaction(transaction.id);
        });

        action.append(badge, document.createTextNode(" "), deleteButton);

        row.append(date, description, category, amount, action);

        transactionList.appendChild(row);
    });
}

// Refresh dashboard
async function refreshDashboard() {
    try {
        await Promise.all([
            loadSummary(),
            loadTransactions()
        ]);
    } catch (error) {
        console.error(error);
        showMessage("Unable to load dashboard data.", true);
    }
}

// Add transaction
form.addEventListener("submit", async function(event) {
    event.preventDefault();

    const transaction = {
        type: document.getElementById("type").value,
        amount: Number(document.getElementById("amount").value),
        category: document.getElementById("category").value,
        date: document.getElementById("date").value,
        description: document.getElementById("description").value.trim()
    };

    if (!Number.isFinite(transaction.amount) ||
        transaction.amount <= 0 ||
        transaction.amount > 1000000000) {
        showMessage("Enter a valid amount.", true);
        return;
    }

    if (!transaction.date) {
        showMessage("Please select a date.", true);
        return;
    }

    const selectedDate = new Date(transaction.date + "T00:00:00");
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (Number.isNaN(selectedDate.getTime()) ||
        selectedDate > today) {
        showMessage("Please select a valid date.", true);
        return;
    }

    try {
        submitButton.disabled = true;
        submitButton.textContent = "Adding...";

        const response = await fetch("/api/transactions", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(transaction)
        });

        const result = await response.json();

        if (!response.ok) {
            throw new Error(result.error || "Unable to add transaction");
        }

        showMessage("Transaction added successfully!");

        form.reset();

        document.getElementById("date").value =
            new Date().toLocaleDateString("en-CA");

        await refreshDashboard();

    } catch (error) {
        showMessage(error.message, true);
    } finally {
        submitButton.disabled = false;
        submitButton.textContent = "+ Add Transaction";
    }
});

// Delete transaction
async function deleteTransaction(id) {
    if (!confirm("Do you want to delete this transaction?")) {
        return;
    }

    try {
        const response = await fetch(`/api/transactions/${id}`, {
            method: "DELETE"
        });

        const result = await response.json();

        if (!response.ok) {
            throw new Error(result.error || "Unable to delete transaction");
        }

        showMessage("Transaction deleted successfully!");

        await refreshDashboard();

    } catch (error) {
        showMessage(error.message, true);
    }
}

// Initial dashboard loading
refreshDashboard();
