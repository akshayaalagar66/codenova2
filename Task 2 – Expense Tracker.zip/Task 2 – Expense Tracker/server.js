
const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const path = require("path");

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const db = new sqlite3.Database(
    path.join(__dirname, "expense.db"),
    (err) => {
        if (err) console.log(err.message);
        else console.log("SQLite Database Connected!");
    }
);

db.serialize(() => {
    db.run(`
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT NOT NULL,
            amount REAL NOT NULL,
            category TEXT NOT NULL,
            description TEXT,
            date TEXT NOT NULL
        )
    `);
});

const categories = [
    "Salary", "Food", "Shopping", "Travel",
    "Bills", "Education", "Health", "Other"
];

function validDate(date) {
    if (typeof date !== "string" ||
        !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
        return false;
    }

    const parsed = new Date(date + "T00:00:00.000Z");

    return !isNaN(parsed.getTime()) &&
        parsed.toISOString().slice(0, 10) === date &&
        date <= new Date().toISOString().slice(0, 10);
}

// GET all transactions
app.get("/api/transactions", (req, res) => {
    db.all(
        "SELECT * FROM transactions ORDER BY date DESC, id DESC",
        [],
        (err, rows) => {
            if (err) {
                return res.status(500).json({
                    error: "Unable to fetch transactions"
                });
            }
            res.json(rows);
        }
    );
});

// GET dashboard summary
app.get("/api/summary", (req, res) => {
    db.get(`
        SELECT
        COALESCE(SUM(CASE WHEN type='income'
        THEN amount ELSE 0 END), 0) AS totalIncome,

        COALESCE(SUM(CASE WHEN type='expense'
        THEN amount ELSE 0 END), 0) AS totalExpenses

        FROM transactions
    `, [], (err, row) => {
        if (err) {
            return res.status(500).json({
                error: "Summary calculation failed"
            });
        }

        res.json({
            totalIncome: row.totalIncome,
            totalExpenses: row.totalExpenses,
            savings: row.totalIncome - row.totalExpenses
        });
    });
});

// ADD transaction
app.post("/api/transactions", (req, res) => {
    const { type, amount, category, description, date } = req.body;

    if (!["income", "expense"].includes(type)) {
        return res.status(400).json({
            error: "Invalid transaction type"
        });
    }

    if (typeof amount !== "number" ||
        !Number.isFinite(amount) ||
        amount <= 0 ||
        amount > 1000000000) {
        return res.status(400).json({
            error: "Enter a valid positive amount"
        });
    }

    if (!categories.includes(category)) {
        return res.status(400).json({
            error: "Invalid category"
        });
    }

    if (!validDate(date)) {
        return res.status(400).json({
            error: "Invalid date. Future dates are not allowed"
        });
    }

    if (description !== undefined &&
        (typeof description !== "string" ||
        description.length > 200)) {
        return res.status(400).json({
            error: "Description must be under 200 characters"
        });
    }

    db.run(`
        INSERT INTO transactions
        (type, amount, category, description, date)
        VALUES (?, ?, ?, ?, ?)
    `, [type, amount, category, description || "", date],
    function(err) {
        if (err) {
            return res.status(500).json({
                error: "Unable to save transaction"
            });
        }

        res.status(201).json({
            message: "Transaction added successfully",
            id: this.lastID
        });
    });
});

// DELETE transaction
app.delete("/api/transactions/:id", (req, res) => {
    const id = Number(req.params.id);

    if (!Number.isInteger(id) || id <= 0) {
        return res.status(400).json({
            error: "Invalid transaction ID"
        });
    }

    db.run(
        "DELETE FROM transactions WHERE id = ?",
        [id],
        function(err) {
            if (err) {
                return res.status(500).json({
                    error: "Delete failed"
                });
            }

            if (this.changes === 0) {
                return res.status(404).json({
                    error: "Transaction not found"
                });
            }

            res.json({
                message: "Transaction deleted successfully"
            });
        }
    );
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
