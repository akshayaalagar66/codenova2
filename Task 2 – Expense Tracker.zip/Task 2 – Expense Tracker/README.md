
# CodeNova Internship - Task 2
# Expense Tracker

## Project Description

Expense Tracker is a full-stack web application
used to manage income, expenses and savings.

## Technologies Used

- HTML
- CSS
- JavaScript
- Node.js
- Express.js
- SQLite

## Features

1. Add income transactions.
2. Add expense transactions.
3. Category selection.
4. Client-side validation.
5. Server-side validation.
6. Total income summary.
7. Total expenses summary.
8. Net savings calculation.
9. Transaction history.
10. Delete transactions.
11. Permanent database storage.
12. Responsive design.

## Installation

Install Node.js.

Open the project folder in VS Code.

Run:

npm install

Start the application:

npm start

Open browser:

http://localhost:3000

## API Contract

### GET /api/transactions
Returns all transactions.

### GET /api/summary
Returns total income, expenses and savings.

### POST /api/transactions
Adds a new transaction.

Example request:

{
  "type": "income",
  "amount": 25000,
  "category": "Salary",
  "description": "Monthly salary",
  "date": "2026-10-30"
}

### DELETE /api/transactions/:id
Deletes a transaction using its ID.

## Database Model

Table Name: transactions

| Field | Type |
|---|---|
| id | INTEGER PRIMARY KEY |
| type | TEXT |
| amount | REAL |
| category | TEXT |
| description | TEXT |
| date | TEXT |

## Database Persistence

SQLite stores all transactions in expense.db.
Records remain available after restarting the server.

## Internship Details

Program: CodeNova Internship
Batch: 01
Task: Task 2 - Expense Tracker
