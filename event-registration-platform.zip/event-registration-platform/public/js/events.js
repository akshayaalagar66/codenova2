const INTERESTS = ['AI/ML', 'Web Development', 'Cyber Security', 'Data Science', 'Cloud', 'Mobile Apps'];

const $ = (sel) => document.querySelector(sel);
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const listEl = $('#events');
const dialog = $('#regDialog');
const form = $('#regForm');
const errorEl = $('#formError');
let events = [];
let activeEvent = null;

function showToast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => (t.hidden = true), 3500);
}

const fmtDate = (iso) =>
  new Date(iso).toLocaleString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' });

async function loadEvents() {
  try {
    const res = await fetch('/api/events');
    events = await res.json();
    render();
  } catch {
    listEl.innerHTML = '<p class="muted">Could not load events. Is the server running?</p>';
  }
}

function render() {
  listEl.innerHTML = events.map((e) => {
    const pct = Math.round((e.registered / e.capacity) * 100);
    const state = e.seats_left === 0 ? 'full' : e.seats_left <= Math.ceil(e.capacity * 0.15) ? 'low' : '';
    return `
      <article class="ticket">
        <div class="ticket-main">
          <p class="when">${fmtDate(e.starts_at)}</p>
          <h2>${esc(e.title)}</h2>
          <p>${esc(e.description)}</p>
          <span class="venue">${esc(e.venue)}</span>
        </div>
        <div class="ticket-stub">
          <div>
            <div class="seats ${state}">${e.seats_left}<small>of ${e.capacity} seats left</small></div>
            <div class="meter ${state}" style="margin-top:.75rem"><span style="width:${pct}%"></span></div>
          </div>
          <button class="btn primary" data-id="${e.id}" ${e.seats_left === 0 ? 'disabled' : ''}>
            ${e.seats_left === 0 ? 'Sold out' : 'Register'}
          </button>
        </div>
      </article>`;
  }).join('');
}

listEl.addEventListener('click', (ev) => {
  const btn = ev.target.closest('button[data-id]');
  if (!btn) return;
  activeEvent = events.find((e) => e.id === Number(btn.dataset.id));
  $('#dlgTitle').textContent = activeEvent.title;
  $('#dlgMeta').textContent = `${fmtDate(activeEvent.starts_at)} · ${activeEvent.venue}`;
  errorEl.hidden = true;
  form.reset();
  dialog.showModal();
});

$('#closeBtn').addEventListener('click', () => dialog.close());
dialog.addEventListener('click', (e) => { if (e.target === dialog) dialog.close(); });

$('#interests').innerHTML = INTERESTS.map(
  (i) => `<label class="chip"><input type="checkbox" value="${i}" /><span>${i}</span></label>`
).join('');

form.addEventListener('submit', async (ev) => {
  ev.preventDefault();
  errorEl.hidden = true;
  const btn = $('#submitBtn');
  btn.disabled = true;

  const data = Object.fromEntries(new FormData(form));
  data.interests = [...form.querySelectorAll('#interests input:checked')].map((c) => c.value);

  try {
    const res = await fetch(`/api/events/${activeEvent.id}/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const body = await res.json();

    if (res.status === 409) {            // duplicate registration
      errorEl.textContent = body.error;
      errorEl.hidden = false;
    } else if (!res.ok) {
      errorEl.textContent = body.error || 'Registration failed.';
      errorEl.hidden = false;
    } else {
      dialog.close();
      showToast(body.message);
      loadEvents();                      // refresh seat counts immediately
    }
  } catch {
    errorEl.textContent = 'Network error. Try again.';
    errorEl.hidden = false;
  } finally {
    btn.disabled = false;
  }
});

loadEvents();
setInterval(loadEvents, 5000);           // counts stay live for other visitors
