const $ = (sel) => document.querySelector(sel);
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

let key = sessionStorage.getItem('adminKey') || prompt('Admin key (default: admin123)') || '';
sessionStorage.setItem('adminKey', key);

const LABEL = { confirmed: 'Confirmed', checked_in: 'Checked in', cancelled: 'Cancelled' };
const headers = () => ({ 'x-admin-key': key, 'Content-Type': 'application/json' });

function toast(msg) {
  const t = $('#toast');
  t.textContent = msg; t.hidden = false;
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => (t.hidden = true), 2500);
}

async function loadEventFilter() {
  const events = await (await fetch('/api/events')).json();
  $('#eventFilter').insertAdjacentHTML('beforeend',
    events.map((e) => `<option value="${e.id}">${esc(e.title)}</option>`).join(''));
}

async function load() {
  const qs = new URLSearchParams({
    search: $('#search').value.trim(),
    event_id: $('#eventFilter').value,
    status: $('#statusFilter').value,
  });
  const res = await fetch(`/api/admin/registrations?${qs}`, { headers: headers() });
  if (res.status === 401) {
    $('#rows').innerHTML = '<tr><td colspan="6" class="empty">Invalid admin key. Reload to try again.</td></tr>';
    sessionStorage.removeItem('adminKey');
    return;
  }
  const { rows, stats } = await res.json();
  renderStats(stats);
  renderRows(rows);
}

function renderStats(s) {
  $('#stats').innerHTML = [
    ['Total', s.total], ['Confirmed', s.confirmed], ['Checked in', s.checked_in], ['Cancelled', s.cancelled],
  ].map(([label, n]) => `<div class="stat"><b>${n}</b><span>${label}</span></div>`).join('');
}

function renderRows(rows) {
  if (!rows.length) {
    $('#rows').innerHTML = '<tr><td colspan="6" class="empty">No attendees match these filters.</td></tr>';
    return;
  }
  $('#rows').innerHTML = rows.map((r) => `
    <tr>
      <td><strong>${esc(r.name)}</strong><span class="sub">${esc(r.email)}</span></td>
      <td>${esc(r.event_title)}</td>
      <td>${esc(r.organization)}</td>
      <td>${esc(r.interests.split(',').filter(Boolean).join(', ') || '-')}</td>
      <td>${esc(new Date(r.created_at.replace(' ', 'T') + 'Z').toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }))}</td>
      <td>
        <span class="badge ${r.status}">${LABEL[r.status]}</span>
        <select class="status-select" data-id="${r.id}" aria-label="Change status for ${esc(r.name)}">
          ${Object.entries(LABEL).map(([v, l]) => `<option value="${v}" ${v === r.status ? 'selected' : ''}>${l}</option>`).join('')}
        </select>
      </td>
    </tr>`).join('');
}

$('#rows').addEventListener('change', async (e) => {
  if (!e.target.matches('.status-select')) return;
  const res = await fetch(`/api/admin/registrations/${e.target.dataset.id}`, {
    method: 'PATCH', headers: headers(), body: JSON.stringify({ status: e.target.value }),
  });
  toast(res.ok ? 'Status updated' : 'Could not update status');
  load();
});

let debounce;
$('#search').addEventListener('input', () => { clearTimeout(debounce); debounce = setTimeout(load, 250); });
$('#eventFilter').addEventListener('change', load);
$('#statusFilter').addEventListener('change', load);

loadEventFilter();
load();
setInterval(load, 10000);
