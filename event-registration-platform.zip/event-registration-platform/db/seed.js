const db = require('./database');

db.exec('DELETE FROM registrations; DELETE FROM events; DELETE FROM sqlite_sequence;');

const addEvent = db.prepare(
  `INSERT INTO events (title, description, venue, starts_at, capacity) VALUES (?, ?, ?, ?, ?)`
);
const addReg = db.prepare(
  `INSERT INTO registrations (event_id, name, email, organization, interests, status) VALUES (?, ?, ?, ?, ?, ?)`
);

db.transaction(() => {
  addEvent.run('AI & ML Build Day', 'A hands-on day of training, tuning and shipping small ML models with mentors from industry.', 'Seminar Hall A, Block 3', '2026-12-05T09:30:00', 60);
  addEvent.run('Secure Code Workshop', 'Find and fix real vulnerabilities in a deliberately broken web app. Bring a laptop.', 'Cyber Lab, Block 5', '2026-12-12T10:00:00', 30);
  addEvent.run('Full Stack Sprint', 'Six hours, one idea, one deployed app. Teams of up to three.', 'Innovation Centre', '2026-12-19T09:00:00', 3);

  addReg.run(1, 'Akshaya N', 'akshaya@example.com', 'Anna University', 'AI/ML,Cyber Security', 'confirmed');
  addReg.run(1, 'Ravi Kumar', 'ravi@example.com', 'SRM Institute', 'Web Development', 'checked_in');
  addReg.run(1, 'Meena S', 'meena@example.com', 'VIT Chennai', 'Data Science', 'cancelled');
  addReg.run(2, 'Karthik R', 'karthik@example.com', 'PSG Tech', 'Cyber Security', 'confirmed');
  addReg.run(3, 'Divya P', 'divya@example.com', 'SSN College', 'Web Development,Cloud', 'confirmed');
  addReg.run(3, 'Arun M', 'arun@example.com', 'CEG Guindy', 'Web Development', 'confirmed');
})();

console.log('Seeded events and registrations.');
