PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS events (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  title       TEXT    NOT NULL,
  description TEXT    NOT NULL,
  venue       TEXT    NOT NULL,
  starts_at   TEXT    NOT NULL,              -- ISO 8601
  capacity    INTEGER NOT NULL CHECK (capacity > 0)
);

CREATE TABLE IF NOT EXISTS registrations (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  event_id     INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  name         TEXT    NOT NULL,
  email        TEXT    NOT NULL,             -- stored lower-case
  organization TEXT    NOT NULL,
  interests    TEXT    NOT NULL DEFAULT '',  -- comma separated domains
  status       TEXT    NOT NULL DEFAULT 'confirmed'
               CHECK (status IN ('confirmed', 'checked_in', 'cancelled')),
  created_at   TEXT    NOT NULL DEFAULT (datetime('now')),
  UNIQUE (event_id, email)                   -- database-level duplicate guard
);

CREATE INDEX IF NOT EXISTS idx_reg_event ON registrations(event_id);
