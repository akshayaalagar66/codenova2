const express = require('express');
const db = require('../db/database');
const router = express.Router();

const ADMIN_KEY = process.env.ADMIN_KEY || 'admin123';

// Minimal header-based guard for the demo
router.use((req, res, next) => {
  if (req.get('x-admin-key') !== ADMIN_KEY) {
    return res.status(401).json({ error: 'Invalid admin key.' });
  }
  next();
});

// GET /api/admin/registrations?search=&event_id=&status=
router.get('/registrations', (req, res) => {
  const { search = '', event_id = '', status = '' } = req.query;
  const where = [];
  const params = {};

  if (search) {
    where.push('(r.name LIKE @q OR r.email LIKE @q OR r.organization LIKE @q)');
    params.q = `%${search}%`;
  }
  if (event_id) { where.push('r.event_id = @event_id'); params.event_id = Number(event_id); }
  if (status)   { where.push('r.status = @status');     params.status = status; }

  const sql = `
    SELECT r.id, r.name, r.email, r.organization, r.interests, r.status, r.created_at,
           e.title AS event_title
    FROM registrations r
    JOIN events e ON e.id = r.event_id
    ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
    ORDER BY r.created_at DESC, r.id DESC`;

  const rows = db.prepare(sql).all(params);
  const stats = db.prepare(`
    SELECT COUNT(*) AS total,
           COALESCE(SUM(status = 'confirmed'), 0)  AS confirmed,
           COALESCE(SUM(status = 'checked_in'), 0) AS checked_in,
           COALESCE(SUM(status = 'cancelled'), 0)  AS cancelled
    FROM registrations`).get();

  res.json({ rows, stats });
});

// PATCH /api/admin/registrations/:id  { status }
router.patch('/registrations/:id', (req, res) => {
  const { status } = req.body;
  if (!['confirmed', 'checked_in', 'cancelled'].includes(status)) {
    return res.status(400).json({ error: 'Invalid status.' });
  }
  const info = db.prepare('UPDATE registrations SET status = ? WHERE id = ?').run(status, req.params.id);
  if (!info.changes) return res.status(404).json({ error: 'Registration not found.' });
  res.json({ ok: true });
});

module.exports = router;
