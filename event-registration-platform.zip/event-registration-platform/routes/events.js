const express = require('express');
const db = require('../db/database');
const router = express.Router();

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const listEvents = db.prepare(`
  SELECT e.*, COUNT(r.id) AS registered
  FROM events e
  LEFT JOIN registrations r ON r.event_id = e.id AND r.status != 'cancelled'
  GROUP BY e.id
  ORDER BY e.starts_at
`);
const getEvent = db.prepare('SELECT * FROM events WHERE id = ?');
const countActive = db.prepare(
  `SELECT COUNT(*) AS n FROM registrations WHERE event_id = ? AND status != 'cancelled'`
);
const findDuplicate = db.prepare('SELECT id FROM registrations WHERE event_id = ? AND email = ?');
const insertReg = db.prepare(`
  INSERT INTO registrations (event_id, name, email, organization, interests)
  VALUES (@event_id, @name, @email, @organization, @interests)
`);

// GET /api/events -> events with live seat counts
router.get('/', (req, res) => {
  const rows = listEvents.all().map((e) => ({
    ...e,
    seats_left: Math.max(e.capacity - e.registered, 0),
  }));
  res.json(rows);
});

// POST /api/events/:id/register
router.post('/:id/register', (req, res) => {
  const eventId = Number(req.params.id);
  const event = getEvent.get(eventId);
  if (!event) return res.status(404).json({ error: 'Event not found.' });

  const name = String(req.body.name || '').trim();
  const email = String(req.body.email || '').trim().toLowerCase();
  const organization = String(req.body.organization || '').trim();
  const interests = Array.isArray(req.body.interests) ? req.body.interests.join(',') : '';

  if (!name || !organization) {
    return res.status(400).json({ error: 'Name and college/organization are required.' });
  }
  if (!EMAIL_RE.test(email)) {
    return res.status(400).json({ error: 'Enter a valid email address.' });
  }

  try {
    // Transaction keeps the capacity check and the insert atomic.
    const register = db.transaction(() => {
      if (findDuplicate.get(eventId, email)) return { duplicate: true };
      if (countActive.get(eventId).n >= event.capacity) return { full: true };
      const info = insertReg.run({ event_id: eventId, name, email, organization, interests });
      return { id: info.lastInsertRowid };
    });

    const result = register();

    if (result.duplicate) {
      return res.status(409).json({
        error: `${email} is already registered for "${event.title}". Use a different email or contact the organisers.`,
      });
    }
    if (result.full) {
      return res.status(400).json({ error: 'This event is full. No seats left.' });
    }
    res.status(201).json({ id: result.id, message: `You're registered for ${event.title}.` });
  } catch (err) {
    // Safety net: UNIQUE(event_id, email) catches race conditions.
    if (String(err.code).startsWith('SQLITE_CONSTRAINT')) {
      return res.status(409).json({ error: 'This email is already registered for this event.' });
    }
    console.error(err);
    res.status(500).json({ error: 'Something went wrong. Try again.' });
  }
});

module.exports = router;
