# Event Registration Platform

Public event showcase, registration with duplicate prevention, and an admin attendee view.

**Stack:** Node.js, Express, SQLite (better-sqlite3), vanilla HTML/CSS/JS.

## Run

```bash
npm install
npm run seed     # creates db/events.sqlite with sample data
npm start        # http://localhost:3000
```

- Public page: `http://localhost:3000`
- Admin: `http://localhost:3000/admin.html` (key: `admin123`, override with `ADMIN_KEY`)

## Project structure

```
event-registration-platform/
├── server.js              # Express app, static files, route mounting
├── db/
│   ├── schema.sql         # tables, constraints, index
│   ├── database.js        # connection + schema bootstrap
│   └── seed.js            # sample events and attendees
├── routes/
│   ├── events.js          # GET events, POST register (409 logic)
│   └── admin.js           # list/search/filter, update status
└── public/
    ├── index.html         # event showcase + registration dialog
    ├── admin.html         # attendee table
    ├── css/styles.css
    └── js/ (events.js, admin.js)
```

## Schema diagram

```mermaid
erDiagram
    EVENTS ||--o{ REGISTRATIONS : "has"
    EVENTS {
        int id PK
        text title
        text description
        text venue
        text starts_at
        int capacity
    }
    REGISTRATIONS {
        int id PK
        int event_id FK
        text name
        text email
        text organization
        text interests
        text status
        text created_at
    }
```

`UNIQUE (event_id, email)` guarantees one email per event at the database level.

## API

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/events` | Events with `registered` and `seats_left` |
| POST | `/api/events/:id/register` | Register. `201` created, `400` invalid or full, `404` unknown event, **`409` duplicate email** |
| GET | `/api/admin/registrations?search=&event_id=&status=` | Admin list and stats (needs `x-admin-key`) |
| PATCH | `/api/admin/registrations/:id` | Change status |

## Seed data

Three events (AI & ML Build Day, Secure Code Workshop, Full Stack Sprint with 3 seats so you can test "full") and six sample attendees. See `db/seed.js`.

## Screenshots

Add to `/screenshots`: `register.png`, `duplicate-409.png`, `admin.png`.

## Testing the 409

Register `akshaya@example.com` for event 1 (already seeded), or register the same email twice. The form shows the conflict message and the API returns status 409.
